# Pyfanity

The easy way to find and censor words in your text.